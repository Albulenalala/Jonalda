<?php
session_start();
include_once("config.php");

$name = htmlspecialchars($_POST['name']);
$email = htmlspecialchars($_POST['email']);
$subject = htmlspecialchars($_POST['subject']);
$comment = htmlspecialchars($_POST['comment']);

$stmt = $conn->prepare("INSERT INTO `contact-us` (name, email, subject, comment) VALUES (?, ?, ?, ?)");
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("ssss", $name, $email, $subject, $comment);

if ($stmt->execute()) {
    $_SESSION['message'] = "Message sent successfully!";
    header("Location: contact.php"); 
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
