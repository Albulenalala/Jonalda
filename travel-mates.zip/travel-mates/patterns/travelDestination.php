<?php
/**
 * Title: Travel Destinations
 * Slug: travel-mates/travelDestinations
 * Categories: travel-mates
 *
 * @package travel-mates
 * @since 1.0.0
 */
include_once("config.php");
$query = "SELECT city, country, continent, trip_type, description, image FROM destination";
$result = mysqli_query($conn, $query);
include_once("../parts/header.html");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Destinations</title>
    <link rel="stylesheet" href="style.css">
</head>
<body id="tdestination" style=" padding-top:80px;padding-right:0;padding-left:0">
    <div id="best-destination" class="travel-location">
        <h2 class="title">Best Destinations</h2>
    
            <h4 style="text-align: center;margin-top:5px">Your next great adventure awaits!</h4>
        </p>
        <div class="best-destination">
            <?php 
            while ($row = $result->fetch_assoc()) {
                echo '<div class="destination">';
                if (!empty($row['image'])) {
                    echo '<div class="cover-image-container">';
                    echo '<img class="cover-image" src="' . htmlspecialchars($row['image']) . '" alt="Image of ' . htmlspecialchars($row['city']) . '">';
                    echo '</div>';
                } else {
                    echo '<p>No image available.</p>';
                }
                echo '<h3 style="padding-top:20px;">' . htmlspecialchars($row['city']) . ', ' . htmlspecialchars($row['country']) . '</h3>';
                echo '<p>Category: ' . htmlspecialchars($row['trip_type']) . '</p>';
                echo '<p style="font-size:18px;">' . htmlspecialchars($row['description']) . '</p>';
                echo '</div>'; 
            }
            ?>
        </div>
    </div>
</body>
<footer>
    <?php
    include_once("../parts/footer.html");
    ?>
</footer>
</html>
