<?php 
session_start();
include '../parts/header.html';
include_once("config.php");

$query = "SELECT trip_id,city, country, continent, quote, price, image FROM destination";
$result = mysqli_query($conn, $query);

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Mates</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="../assets/css/animate.css">
    <link rel="stylesheet" href="../assets/css/light_gallerr.min.css">
    <link rel="stylesheet" href="../assets/css/odometer.css">
    <link rel="stylesheet" href="../assets/css/select2.min.css">
    <link rel="stylesheet" href="../assets/css/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script>
        window.onload = function() {
            <?php
            if (isset($_SESSION['message'])) {
                echo "alert('" . addslashes($_SESSION['message']) . "');";
                unset($_SESSION['message']);
            }
            ?>
        };
    </script>
</head>
  <body>
    <!-- Start Hero Section -->
    <section class="cs_hero cs_style_2 cs_accent_bg_1">
      <div class="cs_hero_in">
        <div class="cs_hero_img"><img src="../assets/images/hero_2.png" alt="Hero Thumb" style="height:1000px;width:1100px"></div>
        <div class="cs_hero_text">
          <h3 class="cs_hero_mini_title cs_fs_24 cs_semibold cs_accent_color wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Find Next PlaceTo Visit</h3>
          <h1 class="cs_hero_title cs_fs_85 cs_semibold">Travel Mates</h1>
          <p class="cs_hero_desc cs_fs_18">Denouncing pleasure and praising pain was born and will give you complete great explorer of the truth the master-builder.</p>
          <div class="cs_button_group">
            <a href="about.php" class="cs_btn cs_style_1 cs_fs_18 cs_semibold">
              Read More
              <svg width="20" height="10" viewBox="0 0 20 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19.5866 5.69629H0.41235C0.184269 5.69629 0 5.46776 0 5.1849C0 4.90204 0.184269 4.67352 0.41235 4.67352H18.5906L16.0881 1.57004C15.927 1.37028 15.927 1.04587 16.0881 0.846109C16.2492 0.646349 16.5108 0.646349 16.6718 0.846109L19.8792 4.82374C19.9977 4.97076 20.0325 5.1897 19.9681 5.38147C19.9036 5.57164 19.7529 5.69629 19.5866 5.69629Z" fill="currentColor"/><path d="M16.3435 9.11986C16.2384 9.11986 16.1333 9.08012 16.0538 8.99935C15.8935 8.83909 15.8935 8.57884 16.0538 8.41858L19.2487 5.22371C19.4089 5.06345 19.6692 5.06345 19.8294 5.22371C19.9897 5.38396 19.9897 5.64422 19.8294 5.80448L16.6346 8.99935C16.5538 9.08012 16.4487 9.11986 16.3435 9.11986Z" fill="currentColor"/>
              </svg>                
            </a>
            <div class="cs_hero_ratings wow fadeInRight" data-wow-duration="0.8s" data-wow-delay="0.2s">
              <div class="cs_hero_rating_icon">
                <img src="../assets/images/icons/google_icon.svg" alt="Icom">
              </div>
              <div class="cs_rating_container">
                <div class="cs_rating" data-rating="4.9">
                  <div class="cs_rating_percentage"></div>
                </div>
                <div class="cs_rating_text cs_fs_25 cs_normal">4.9 Rating</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="animated-icon-wrap">
        <div class="animated-icon"><i class="fa-solid fa-location-dot"></i></div>
        <div class="animated-icon"><i class="fa-solid fa-car"></i></div>
        <div class="animated-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="animated-icon"><i class="fa-solid fa-globe"></i></div>
        <div class="animated-icon"><i class="fa-solid fa-earth-americas"></i></div>
        <div class="animated-icon"><i class="fa-regular fa-compass"></i></div>
        <div class="animated-icon"><i class="fa-solid fa-hotel"></i></div>
      </div>
    </section>
    <!-- End Hero Section -->
    
    <!-- Start Package Section -->
    <section>
    <div class="cs_height_140 cs_height_lg_80"></div>
    <div class="container">
        <div class="row cs_gap_y_24">
            <?php 
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="col-lg-4">';
                echo '<div class="cs_card cs_style_3 cs_white_bg">';
                echo '<a href="tour-details.php?id=' . htmlspecialchars($row['trip_id']) . '" class="cs_card_thumb position-relative cs_zoom">';

                if (!empty($row['image'])) {
                    echo '<img src="' . htmlspecialchars($row['image']) . '" alt="Package Thumb" class="cs_zoom_in fixed-size">';
                } else {
                    echo '<img src="assets/images/default-image.jpeg" alt="Default Image" class="cs_zoom_in">';
                }

                echo '<div class="cs_package_badge cs_fs_18 cs_semibold cs_primary_color cs_primary_font position-absolute">' . htmlspecialchars($row['quote']) . '</div>';
                echo '</a>';
                echo '<div class="cs_card_content">';
                echo '<h2 class="cs_card_title cs_fs_24 cs_semibold"><a href="trip-details.php?id=' . htmlspecialchars($row['trip_id']) . '">' . htmlspecialchars($row['city']) . '</a></h2>';
                echo '<p class="cs_card_subtitle mb-0"><i class="fa-solid fa-globe cs_accent_color"></i> ' . htmlspecialchars($row['city']) . ', ' . htmlspecialchars($row['country']) . '</p>';
                echo '<hr>';
                echo '<div class="cs_card_action">';
                echo '<span class="cs_card_price cs_fs_24 cs_semibold cs_primary_color cs_primary_font mb-0">$' . htmlspecialchars($row['price']) . '</span>';
                echo '<a href="trip-details.php?id=' . htmlspecialchars($row['trip_id']) . '" class="cs_btn cs_style_1 cs_fs_18 cs_semibold">Book Now</a>';
                echo '</div>';
                echo '</div>'; 
                echo '</div>'; 
                echo '</div>'; 
            }
            ?>
        </div>
    </div>
    <div class="cs_height_140 cs_height_lg_80"></div>
</section>

    <!-- End Package Section -->
    
    <!-- Start Destination Section -->
    <section>
    <div class="cs_section_heading cs_style_1" style="text-align:center;">
          <h3 class="cs_section_title_up cs_ternary_font cs_accent_color cs_normal cs_fs_24">POPULAR DESTINATION</h3>
          <h2 class="cs_section_title cs_semibold cs_fs_56 mb-0 wow fadeInRight" data-wow-duration="0.8s" data-wow-delay="0.2s">Most Popular Destination</h2>
        </div>
      <div class="cs_height_140 cs_height_lg_80"></div>
      <div class="container">
        <div class="cs_grid_1">
          <div class="cs_grid_item">
            <a href="trips.php" class="cs_card cs_style_2 cs_zoom position-relative cs_radius_8">
              <div class="cs_card_thumb w-100 h-100">
                <img src="../assets/images/popular_destination_1.jpeg" alt="Card Image" class="w-100 h-100 cs_zoom_in">
              </div>
              <div class="cs_card_content position-absolute">
                <h2 class="cs_card_title cs_fs_35 cs_medium cs_white_color">Eiffel Tower</h2>
                <p class="cs_card_subtitle cs_fs_18 cs_medium cs_white_color mb-0">Paris, 24 Trips</p>
              </div>
            </a>
          </div>
          <div class="cs_grid_item">
            <a href="trips.php" class="cs_card cs_style_2 cs_zoom position-relative cs_radius_8">
              <div class="cs_card_thumb w-100 h-100">
                <img src="../assets/images/popular_destination_2.jpeg" alt="Card Image" class="w-100 h-100 cs_zoom_in">
              </div>
              <div class="cs_card_content position-absolute">
                <h2 class="cs_card_title cs_fs_35 cs_medium cs_white_color">
                  Pryde Mountains</h2>
                <p class="cs_card_subtitle cs_fs_18 cs_medium cs_white_color mb-0">
                 Prydelands, 100 Trips</p>
              </div>
            </a>
          </div>
          <div class="cs_grid_item">
            <a href="trips.php" class="cs_card cs_style_2 cs_zoom position-relative cs_radius_8">
              <div class="cs_card_thumb w-100 h-100">
                <img src="../assets/images/popular_destination_3.jpeg" alt="Card Image" class="w-100 h-100 cs_zoom_in">
              </div>
              <div class="cs_card_content position-absolute">
                <h2 class="cs_card_title cs_fs_35 cs_medium cs_white_color">Lao Lading Island</h2>
                <p class="cs_card_subtitle cs_fs_18 cs_medium cs_white_color mb-0">Krabal, 12 Trips</p>
              </div>
            </a>
          </div>
          <div class="cs_grid_item">
            <a href="trips.php" class="cs_card cs_style_2 cs_zoom position-relative cs_radius_8">
              <div class="cs_card_thumb w-100 h-100">
                <img src="../assets/images/popular_destination_4.jpeg" alt="Card Image" class="w-100 h-100 cs_zoom_in">
              </div>
              <div class="cs_card_content position-absolute">
                <h2 class="cs_card_title cs_fs_35 cs_medium cs_white_color">Ton Kwen Temple</h2>
                <p class="cs_card_subtitle cs_fs_18 cs_medium cs_white_color mb-0">Thailand, 20 Trips</p>
              </div>
            </a>
          </div>
          <div class="cs_grid_item">
            <a href="trips.php" class="cs_card cs_style_2 cs_zoom position-relative cs_radius_8">
              <div class="cs_card_thumb w-100 h-100">
                <img src="../assets/images/popular_destination_5.jpeg" alt="Card Image" class="w-100 h-100 cs_zoom_in">
              </div>
              <div class="cs_card_content position-absolute">
                <h2 class="cs_card_title cs_fs_35 cs_medium cs_white_color">Taj Mahal</h2>
                <p class="cs_card_subtitle cs_fs_18 cs_medium cs_white_color mb-0">Thailand, 50 Trips</p>
              </div>
            </a>
          </div>
          <div class="cs_grid_item">
            <a href="trips.php" class="cs_card cs_style_2 cs_zoom position-relative cs_radius_8">
              <div class="cs_card_thumb w-100 h-100">
                <img src="../assets/images/popular_destination_9.jpeg" alt="Card Image" class="w-100 h-100 cs_zoom_in">
              </div>
              <div class="cs_card_content position-absolute">
                <h2 class="cs_card_title cs_fs_35 cs_medium cs_white_color">
                  Pryde Mountains</h2>
                <p class="cs_card_subtitle cs_fs_18 cs_medium cs_white_color mb-0">
                 Prydelands, 120 Trips</p>
              </div>
            </a>
          </div>
          <div class="cs_grid_item">
            <a href="trips.php" class="cs_card cs_style_2 cs_zoom position-relative cs_radius_8">
              <div class="cs_card_thumb w-100 h-100">
                <img src="../assets/images/popular_destination_1.jpeg" alt="Card Image" class="w-100 h-100 cs_zoom_in">
              </div>
              <div class="cs_card_content position-absolute">
                <h2 class="cs_card_title cs_fs_35 cs_medium cs_white_color">Eiffel Tower</h2>
                <p class="cs_card_subtitle cs_fs_18 cs_medium cs_white_color mb-0">Paris, 24 Trips</p>
              </div>
            </a>
          </div>
        </div>
      </div>
      <div class="cs_height_140 cs_height_lg_80"></div>
    </section>
    <!-- End Destination Section -->
    <!-- Start Team Section -->
     <section>
      <div class="cs_height_135 cs_height_lg_75"></div>
      <div class="container">
        <div class="cs_section_heading cs_style_1 text-center">
          <h3 class="cs_section_title_up cs_ternary_font cs_accent_color cs_normal cs_fs_24">Travel Agents</h3>
          <h2 class="cs_section_title cs_semibold cs_fs_56 mb-0 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Our Experts Team Member</h2>
        </div>
        <div class="cs_height_55 cs_height_lg_40"></div>
        <div class="row cs_gap_y_30">
          <div class="col-lg-4">
            <div class="cs_team cs_style_1 position-relative">
              <div class="cs_team_thumb cs_zoom overflow-hidden">
                <img src="../assets/images/team_1.jpeg" alt="Team Thumb" class="cs_zoom_in">
              </div>
              <div class="cs_team_info text-center position-absolute">
                <h2 class="cs_team_title cs_fs_24 cs_medium cs_white_color">David Cooper</h2>
               <p class="cs_team_subtitle cs_white_color">CO FOUNDER</p>
               <div class="cs_social_btns">
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
              </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="cs_team cs_style_1 position-relative">
              <div class="cs_team_thumb cs_zoom overflow-hidden">
                <img src="../assets/images/team_2.jpeg" alt="Team Thumb" class="cs_zoom_in">
              </div>
              <div class="cs_team_info text-center position-absolute">
                <h2 class="cs_team_title cs_fs_24 cs_medium cs_white_color">David Cooper</h2>
               <p class="cs_team_subtitle cs_white_color">CO FOUNDER</p>
               <div class="cs_social_btns">
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
              </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="cs_team cs_style_1 position-relative">
              <div class="cs_team_thumb cs_zoom overflow-hidden">
                <img src="../assets/images/team_3.jpeg" alt="Team Thumb" class="cs_zoom_in">
              </div>
              <div class="cs_team_info text-center position-absolute">
                <h2 class="cs_team_title cs_fs_24 cs_medium cs_white_color">David Cooper</h2>
               <p class="cs_team_subtitle cs_white_color">CO FOUNDER</p>
               <div class="cs_social_btns">
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="cs_height_140 cs_height_lg_80"></div>
    </section>
    <!-- End Team Section -->
    <!-- Start Accordian Section -->
    <section class="cs_primary_bg cs_bg_filed cs_bg_fixed cs_parallax" data-src="../assets/images/accordian_bg.jpeg">
      <div class="cs_height_150 cs_height_lg_80"></div>
      <div class="container">
        <div class="row cs_gap_y_40 align-items-center">
          <div class="col-xl-6 col-lg-5">
            <div class="cs_adventure_logo_wrap">
              <div class="cs_adventure_logo">
                <img src="../assets/images/adventure_logo.svg" alt="Logo" class="cs_to_rotate">
              </div>
            </div>
          </div>
          <div class="col-xl-6 col-lg-7">
            <div class="cs_accordian_wrap">
              <div class="cs_accordian cs_style_1 cs_white_bg cs_radius_5">
                <h3 class="cs_accordian_head cs_fs_20 cs_semibold mb-0">
                  <span>What type of travel packages does Vacasky offer?</span>
                    <span class="cs_accordian_toggle cs_center">
                      <i class="fa-regular fa-eye"></i>
                      <i class="fa-regular fa-eye-slash"></i>
                    </span>
                </h3>
                <div class="cs_accordian_body">
                  There are many variations of passages of available but the Ut elit tellus luctus nec ullamcorper at mattis variations of passages of available.
                </div>
              </div>
              <div class="cs_accordian cs_style_1 cs_white_bg cs_radius_5 active">
                <h3 class="cs_accordian_head cs_fs_20 cs_semibold mb-0">
                  How do I book a trip with Vacasky?
                    <span class="cs_accordian_toggle cs_center">
                      <i class="fa-regular fa-eye"></i>
                      <i class="fa-regular fa-eye-slash"></i>
                    </span>
                </h3>
                <div class="cs_accordian_body">
                  There are many variations of passages of available but the Ut elit tellus luctus nec ullamcorper at mattis variations of passages of available.
                </div>
              </div>
              <div class="cs_accordian cs_style_1 cs_white_bg cs_radius_5">
                <h3 class="cs_accordian_head cs_fs_20 cs_semibold mb-0">
                  What is the payment process for Vacasky?
                  <span class="cs_accordian_toggle cs_center">
                    <i class="fa-regular fa-eye"></i>
                    <i class="fa-regular fa-eye-slash"></i>
                  </span>
                </h3>
                <div class="cs_accordian_body">
                  There are many variations of passages of available but the Ut elit tellus luctus nec ullamcorper at mattis variations of passages of available.
                </div>
              </div>
              <div class="cs_accordian cs_style_1 cs_white_bg cs_radius_5">
                <h3 class="cs_accordian_head cs_fs_20 cs_semibold mb-0">
                  What Payment Methods are Supported?
                    <span class="cs_accordian_toggle cs_center">
                      <i class="fa-regular fa-eye"></i>
                      <i class="fa-regular fa-eye-slash"></i>
                    </span>
                </h3>
                <div class="cs_accordian_body">
                  There are many variations of passages of available but the Ut elit tellus luctus nec ullamcorper at mattis variations of passages of available.
                </div>
              </div>
              <div class="cs_accordian cs_style_1 cs_white_bg cs_radius_5">
                <h3 class="cs_accordian_head cs_fs_20 cs_semibold mb-0">
                  How to cancel my booking in Vacasky?
                    <span class="cs_accordian_toggle cs_center">
                      <i class="fa-regular fa-eye"></i>
                      <i class="fa-regular fa-eye-slash"></i>
                    </span>
                </h3>
                <div class="cs_accordian_body">
                  There are many variations of passages of available but the Ut elit tellus luctus nec ullamcorper at mattis variations of passages of available.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="cs_height_150 cs_height_lg_80"></div>
    </section>
    <!-- End Accordian Section -->
   

    <!-- Start footer -->
    <?php include_once("../parts/footer.html");?>
    <!-- End footer -->

    <!-- Script -->
    <?php include_once("../partials/script.php")?>
  </body>
</html>