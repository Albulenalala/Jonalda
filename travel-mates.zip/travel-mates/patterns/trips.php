
<?php 
include_once("config.php");
$query = "SELECT trip_id,city, country, continent, quote, price, image FROM destination";
$result = mysqli_query($conn, $query);
include_once("../parts/header.html");
?>

<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Mates</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="../assets/css/animate.css">
    <link rel="stylesheet" href="../assets/css/light_gallerr.min.css">
    <link rel="stylesheet" href="../assets/css/odometer.css">
    <link rel="stylesheet" href="../assets/css/select2.min.css">
    <link rel="stylesheet" href="../assets/css/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>

   <!-- Start Package Section -->
<section>
    <div class="cs_height_140 cs_height_lg_80"></div>
    <div class="container">
        <div class="row cs_gap_y_24">
            <?php 
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="col-lg-4">';
                echo '<div class="cs_card cs_style_3 cs_white_bg">';
                echo '<a href="tour-details.php?id=' . htmlspecialchars($row['trip_id']) . '" class="cs_card_thumb position-relative cs_zoom">';

                if (!empty($row['image'])) {
                    echo '<img src="' . htmlspecialchars($row['image']) . '" alt="Package Thumb" class="cs_zoom_in fixed-size">';
                } else {
                    echo '<img src="assets/images/default-image.jpeg" alt="Default Image" class="cs_zoom_in">';
                }

                echo '<div class="cs_package_badge cs_fs_18 cs_semibold cs_primary_color cs_primary_font position-absolute">' . htmlspecialchars($row['quote']) . '</div>';
                echo '</a>';
                echo '<div class="cs_card_content">';
                echo '<h2 class="cs_card_title cs_fs_24 cs_semibold"><a href="trip-details.php?id=' . htmlspecialchars($row['trip_id']) . '">' . htmlspecialchars($row['city']) . '</a></h2>';
                echo '<p class="cs_card_subtitle mb-0"><i class="fa-solid fa-globe cs_accent_color"></i> ' . htmlspecialchars($row['city']) . ', ' . htmlspecialchars($row['country']) . '</p>';
                echo '<hr>';
                echo '<div class="cs_card_action">';
                echo '<span class="cs_card_price cs_fs_24 cs_semibold cs_primary_color cs_primary_font mb-0">$' . htmlspecialchars($row['price']) . '</span>';
                echo '<a href="trip-details.php?id=' . htmlspecialchars($row['trip_id']) . '" class="cs_btn cs_style_1 cs_fs_18 cs_semibold">Book Now</a>';
                echo '</div>';
                echo '</div>'; 
                echo '</div>'; 
                echo '</div>'; 
            }
            ?>
        </div>
    </div>
    <div class="cs_height_140 cs_height_lg_80"></div>
</section>
<!-- End Package Section -->
<?php include_once("../parts/footer.html");?>
<!-- End footer -->

<!-- Script -->
<?php include_once("../partials/script.php")?>
