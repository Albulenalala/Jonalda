<?php
/**
 * Title: Latest Blog
 * Slug: travel-mates/latestBlog
 * Categories: travel-mates
 *
 * @package travel-mates
 * @since 1.0.0
 */
include_once("config.php");
$query="SELECT username,destination,description, evaluation FROM blog";
$result=mysqli_query($conn,$query);
include_once("../parts/header.html");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Latest Blogs</title>
</head>
<body > 
    <div id="latest-blog" class="wp-block-groupb has-bright-background-color has-background" style="padding-top:80px;padding-right:0;padding-left:0">
        <div id="background">
            <div class="wp-block-groupb alignwide" style="align-items:wide;">
                <div class="wp-block-group alignwide" style="display:flex;flex-direction:column">
                    <h3 class="wp-block-heading alignwide has-text-align-left"><strong>Latest Blogs</strong></h3>
                    <p id="blogp">Explore the world with us! Our travel agency blog is your ultimate resource for discovering hidden gems, travel tips, and destination highlights.
                        Whether you're seeking adventure, relaxation, or cultural experiences, we provide expert insights and inspiration to help you plan unforgettable journeys.
                        <br>Join us as we share travel stories, itineraries, and the latest trends to make your next getaway truly remarkable!</p>
                </div>
            </div>
        </div>
  

        <div class="wp-block-groupb alignfull" id="wpalign" style="margin-top:60px;">
            <div class="wp-block-query alignfull">
                <div class="wp-block-cover is-light" style="min-height:500px;">
                    <div class="wp-block-cover__inner-container">
                        <div class="wp-block-groupb">
                            <?php 
                                while($row = $result->fetch_assoc()) {
                                    echo '<div class="user-post">';
                                    echo '<h2>' . htmlspecialchars($row['username']) . '</h2>';
                                    echo '<p>Destination: ' .htmlspecialchars($row['destination']) . '</p>';
                                    echo '<p>Description: ' . htmlspecialchars($row['description']) . '</p>';
                                    echo '<p>Rating: ' . htmlspecialchars($row['evaluation']) . '/5</p>';
                                    echo '</div>';
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<footer>
<?php 
    include_once("../parts/footer.html");
    ?>
</footer>
</html>

