<?php 
include '../parts/header.html';
include_once("config.php");


$trip_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$query = "SELECT * FROM destination WHERE trip_id = $trip_id";
$result = mysqli_query($conn, $query);


if (!$result || mysqli_num_rows($result) === 0) {
    die("Trip not found or query failed: " . mysqli_error($conn));
}

$trip = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($trip['city']); ?> - Travel Mates</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="../assets/css/animate.css">
    <link rel="stylesheet" href="../assets/css/light_gallery.min.css">
    <link rel="stylesheet" href="../assets/css/odometer.css">
    <link rel="stylesheet" href="../assets/css/select2.min.css">
    <link rel="stylesheet" href="../assets/css/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script>
    function updateReturnDate() {
        const departureInput = document.getElementById('departure_date');
        const returnInput = document.getElementById('return_date');

        const departureDate = new Date(departureInput.value);
        departureDate.setDate(departureDate.getDate() + 2); 


        const year = departureDate.getFullYear();
        const month = String(departureDate.getMonth() + 1).padStart(2, '0'); 
        const day = String(departureDate.getDate()).padStart(2, '0');

        returnInput.value = `${year}-${month}-${day}`;
    }
</script>
</head>

<!-- Start Destination Details Section -->
<section>
    <div class="cs_height_140 cs_height_lg_80"></div>
    <div class="container">
        <div class="row cs_gap_y_50">
            <div class="col-lg-8">
                <div class="cs_post_details">
                <div class="row justify-content-center">
                <h3 class="cs_section_title_up cs_ternary_font cs_accent_color cs_normal cs_fs_24" style="text-align:center;">BOOK YOUR GETAWAY</h3>
                    <div class="col-lg-6 text-center">
                        <img src="<?php echo htmlspecialchars($trip['image']); ?>" alt="Destination Image" class="img-fluid">
                    </div>
                </div>

                    <h2><?php echo htmlspecialchars($trip['city']); ?></h2>
                    <p><?php echo htmlspecialchars($trip['description']); ?></p>
                    <div class="cs_list_wrapper cs_gray_bg">
                        <h3 class="cs_fs_20 cs_medium">Good to Know:</h3>
                        <ul class="cs_list cs_style_2 cs_fs_18 cs_primary_color">
                            <li>
                                <i><img src="../assets/images/icons/location.svg" alt="Icon"></i>
                                <span>Country: <?php echo htmlspecialchars($trip['country']); ?></span>
                            </li>
                            <li>
                                <i><img src="../assets/images/icons/visa.svg" alt="Icon"></i>
                                <span>Visa Requirements: <?php echo htmlspecialchars($trip['visa']);?></span>
                            </li>
                            <li>
                                <i><img src="../assets/images/icons/language.svg" alt="Icon"></i>
                                <span>Languages spoken: <?php echo htmlspecialchars($trip['language']);?></span>
                            </li>
                            <li>
                                <i><img src="../assets/images/icons/rate.svg" alt="Icon"></i>
                                <span>Per Person: $<?php echo htmlspecialchars($trip['price']); ?></span>
                            </li>
                            <li>
                                <i><img src="../assets/images/icons/area.svg" alt="Icon"></i>
                                <span>Area (km²): <?php echo htmlspecialchars($trip['area']);?></span>
                            </li>
                            <li>
                                <i><img src="../assets/images/icons/location.svg" alt="Icon"></i>
                                <span>City: <?php echo htmlspecialchars($trip['city']); ?></span>
                            </li>
                        </ul>
                    </div>
                    

                </div>

                
            </div>

            <aside class="col-lg-4">
                <div class="cs_sidebar cs_style_1 cs_white_bg cs_right_sidebar">
                    <div class="cs_info_widget cs_white_bg">
                        <h3 class="cs_widget_title cs_fs_24 cs_medium">Basic Information:</h3>
                        <ul class="cs_info_list cs_mp0">
                            <li class="cs_info_item">
                                <h3 class="cs_info_title cs_fs_16 cs_semibold mb-0">Destination</h3>
                                <p class="cs_info_subtitle mb-0"><?php echo htmlspecialchars($trip['city']); ?></p>
                            </li>
                            <li class="cs_info_item">
                                <h3 class="cs_info_title cs_fs_16 cs_semibold mb-0">Duration</h3>
                                <p class="cs_info_subtitle mb-0">3 Days 2 Nights</p>
                            </li>
                          
                            <li class="cs_info_item">
                                <h3 class="cs_info_title cs_fs_16 cs_semibold mb-0">Dress Code</h3>
                                <p class="cs_info_subtitle mb-0">Casual, comfortable and light</p>
                            </li>
                            <li class="cs_info_item">
                                <h3 class="cs_info_title cs_fs_16 cs_semibold mb-0">Included</h3>
                                <p class="cs_info_subtitle mb-0"><?php echo htmlspecialchars($trip['includes']); ?></p>
                            </li>
                            <li class="cs_info_item">
                                <h3 class="cs_info_title cs_fs_16 cs_semibold mb-0">Not Included</h3>
                                <p class="cs_info_subtitle mb-0"><?php echo htmlspecialchars($trip['excludes']); ?></p>
                            </li>
                        </ul>
                    </div>
                    <div class="cs_post_widget">
                        <h3 class="cs_widget_title cs_fs_24 cs_semibold">Popular Destination</h3>
                        <ul class="cs_recent_posts cs_mp0">
                            <li>
                                <article class="cs_recent_post">
                                    <a href="trips.php" class="cs_recent_post_thumb cs_zoom">
                                        <img src="../assets/c2.jpg" alt="Post Thumb" class="cs_zoom_in w-100 h-100 object-fit-cover">
                                    </a>
                                    <div class="cs_recent_post_info">
                                        <h3 class="cs_recent_post_title cs_fs_18 cs_medium">
                                            <a href="trips.php">Paris</a>
                                        </h3>
                                        <div class="cs_recent_post_meta">
                                            <span>France</span>
                                        </div>
                                    </div>
                                </article>
                            </li>
                        </ul>
                    </div>
                </div>
            </aside>
       
        <form action="book.php" method="POST" class="cs_contact_form row cs_gap_y_24">
        <input type="hidden" name="trip_id" value="<?php echo htmlspecialchars($trip_id); ?>">
            <div class="col-lg-6">
                <div class="cs_input_field">
                    <input type="text" name="name" placeholder="Enter Your Name" class="cs_form_field cs_radius_5" required>
                    <span><i class="fa-regular fa-user"></i></span>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="cs_input_field">
                    <input class="cs_form_field cs_radius_5 cs_white_bg" type="email" name="email" placeholder="Enter Your E-Mail" required>
                    <span><i class="fa-regular fa-envelope"></i></span>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="cs_input_field">
                    <input type="text" name="number" placeholder="Enter Your Number" class="cs_form_field cs_radius_5" required>
                    <span><i class="fa-solid fa-phone"></i></span>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="cs_input_field">
                    <input class="cs_form_field cs_radius_5 cs_white_bg" type="text" name="person-number" placeholder="Enter persons number" required>
                    <span><i class="fa-regular fa-user"></i></span>
                </div>
            </div>
            <div class="col-lg-12">
                <input class="cs_form_field cs_radius_5 cs_white_bg" type="text" name="departure" placeholder="Enter departure place" required>
            </div>
            <div class="col-lg-6">
        <div class="cs_input_field">
            <input type="date" id="departure_date" name="departure_date" class="cs_form_field cs_radius_5" required onchange="updateReturnDate()">
            <span><i class="fa-solid fa-calendar-alt"></i></span>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="cs_input_field">
            <input type="date" id="return_date" name="return_date" class="cs_form_field cs_radius_5" required>
            <span><i class="fa-solid fa-calendar-alt"></i></span>
        </div>
    </div>
            
            <div class="col-lg-12 text-center">
                <button type="submit" class="cs_btn cs_style_1 cs_fs_18 cs_medium cs_radius_4">
                    <i class="fa-regular fa-envelope"></i> BOOK NOW 
                </button>
            </div>
        </form>
    </div>
    <br>
    <blockquote>“Travel is the only thing you buy that makes you richer.”</blockquote>
                    <p>Discover more about the destination, tips, and advice for travelers.</p>
                    <div class="cs_social_btns cs_primary_color">
                    <a href="https://www.facebook.com/"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa-brands fa-linkedin-in"></i></a>
                    <a href="https://www.pinterest.com/"><i class="fa-brands fa-pinterest"></i></a>
                </div>
                <hr>
        </div>
    </div>
    <div class="cs_height_140 cs_height_lg_80"></div>
</section>
<!-- End Destination Details Section -->

<!-- Start footer -->
<?php include_once("../parts/footer.html");?>
<!-- End footer -->

<!-- Script -->
<?php include_once("../partials/script.php")?>
</body>
</html>
