<?php
session_start();
include_once("config.php");
$trip_id = isset($_POST['trip_id']) ? intval($_POST['trip_id']) : 0;
$name = htmlspecialchars($_POST['name']);
$email = htmlspecialchars($_POST['email']);
$number=htmlspecialchars($_POST['number']);
$personnr=htmlspecialchars($_POST['person-number']);
$departure = htmlspecialchars($_POST['departure']);
$dep_date = htmlspecialchars($_POST['departure_date']);
$return_date = htmlspecialchars($_POST['return_date']);

$stmt = $conn->prepare("INSERT INTO `book` (trip_id,name, email, phone_nr, nr_persons, departure, departure_date, return_date) VALUES (?,?, ?, ?, ?, ?, ?, ?)");
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("sssssisi",$trip_id, $name, $email, $number, $personnr, $departure, $dep_date, $return_date);

if ($stmt->execute()) {
    $_SESSION['message'] = "Message sent successfully! Our team will contact you soon";
    header("Location: home.php"); 
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
 