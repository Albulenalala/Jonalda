<?php 
session_start(); 
include '../parts/header.html';
include_once("config.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="../assets/css/animate.css">
    <link rel="stylesheet" href="../assets/css/light_gallerr.min.css">
    <link rel="stylesheet" href="../assets/css/odometer.css">
    <link rel="stylesheet" href="../assets/css/select2.min.css">
    <link rel="stylesheet" href="../assets/css/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script>
        window.onload = function() {
            <?php
            if (isset($_SESSION['message'])) {
                echo "alert('" . addslashes($_SESSION['message']) . "');";
                unset($_SESSION['message']); // Clear the message after showing it
            }
            ?>
        };
    </script>
</head>

<body>

<!-- Start Hero Section -->
<div class="contactt" style="margin-right: 300px; margin-left: 300px;margin-bottom:50px; padding-top: 100px; padding-bottom: 100px; position: relative; overflow: hidden;">
    <img src="../assets/images/six.jpg" alt="background" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; opacity: 0.5;">
    <h1 style="color: black; text-align: center; font-weight: bolder; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 2;">CONTACT US</h1>
</div>

<!-- Start Contact Section -->
<section>
    <div class="container">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success text-center">
                <?php
                echo $_SESSION['message'];
                unset($_SESSION['message']); 
                ?>
            </div>
        <?php endif; ?>
        
        <div class="row cs_gap_y_40">
            <div class="col-lg-3 col-md-6">
                <div class="cs_iconbox cs_style_5 cs_gray_bg cs_radius_5 text-center">
                    <div class="cs_iconbox_icon cs_accent_bg cs_white_color cs_center cs_radius_5" style="background-color: #3fd0d4">
                    <i class="fa-solid fa-location-dot"></i></div>
                    <h2 class="cs_iconbox_title cs_fs_24 cs_semibold">Office Address</h2>
                    <p class="cs_iconbox_subtitle mb-0">Kavaja Street <br> Tirana,Albania</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="cs_iconbox cs_style_5 cs_gray_bg cs_radius_5 text-center">
                    <div class="cs_iconbox_icon cs_accent_bg cs_white_color cs_center cs_radius_5" style="background-color: #3fd0d4"><i class="fa-solid fa-phone"></i></div>
                    <h2 class="cs_iconbox_title cs_fs_24 cs_semibold">Phone Call</h2>
                    <p class="cs_iconbox_subtitle mb-0">+35569875484 <br>+35568789856</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="cs_iconbox cs_style_5 cs_gray_bg cs_radius_5 text-center">
                    <div class="cs_iconbox_icon cs_accent_bg cs_white_color cs_center cs_radius_5" style="background-color: #3fd0d4"><i class="fa-solid fa-envelope"></i></div>
                    <h2 class="cs_iconbox_title cs_fs_24 cs_semibold">E-Mail Us</h2>
                    <p class="cs_iconbox_subtitle mb-0">travelmates@gmail.com <br> travelmates@gmail.com</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="cs_iconbox cs_style_5 cs_gray_bg cs_radius_5 text-center">
                    <div class="cs_iconbox_icon cs_accent_bg cs_white_color cs_center cs_radius_5" style="background-color: #3fd0d4"><i class="fa-solid fa-headset"></i></div>
                    <h2 class="cs_iconbox_title cs_fs_24 cs_semibold">Supports</h2>
                    <p class="cs_iconbox_subtitle mb-0">24/7 any time support team <br> ready for supports.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="cs_height_140 cs_height_lg_80"></div>
</section>
<!-- End Contact Section -->

<!-- Start Contact Form Section -->
<section class="cs_gray_bg">
    <div class="cs_height_135 cs_height_lg_75"></div>
    <div class="container">
        <div class="cs_section_heading cs_style_1 text-center">
            <h3 class="cs_section_title_up cs_ternary_font cs_accent_color cs_normal cs_fs_24" style="color: #3fd0d4;">CONTACT US</h3>
            <h2 class="cs_section_title cs_semibold cs_fs_56 mb-0">Contact Information</h2>
        </div>
        <div class="cs_height_55 cs_height_lg_40"></div>
        <form action="submit_contact.php" method="POST" class="cs_contact_form row cs_gap_y_24">
            <div class="col-lg-6">
                <div class="cs_input_field">
                    <input type="text" name="name" placeholder="Enter Your Name" class="cs_form_field cs_radius_5" required>
                    <span><i class="fa-regular fa-user"></i></span>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="cs_input_field">
                    <input class="cs_form_field cs_radius_5 cs_white_bg" type="email" name="email" placeholder="Enter Your E-Mail" required>
                    <span><i class="fa-regular fa-envelope"></i></span>
                </div>
            </div>
            <div class="col-lg-12">
                <input class="cs_form_field cs_radius_5 cs_white_bg" type="text" name="subject" placeholder="Subject" required>
            </div>
            <div class="col-lg-12">
                <textarea rows="5" name="comment" class="cs_form_field cs_radius_5 cs_white_bg" placeholder="Write Message..." required></textarea>
            </div>
            <div class="col-lg-12 text-center">
                <button type="submit" class="cs_btn cs_style_1 cs_fs_18 cs_medium cs_radius_4">
                    <i class="fa-regular fa-envelope"></i> Send Message
                </button>
            </div>
        </form>
    </div>
    <div class="cs_height_100 cs_height_lg_60"></div>
</section>
<!-- End Contact Form Section -->

<!-- Start Location Section -->
<div class="cs_google_map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d47934.06594227843!2d19.776623758452573!3d41.333241804061544!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1350310470fac5db%3A0x40092af10653720!2sTirana%2C%20Albania!5e0!3m2!1sen!2s!4v1729843316685!5m2!1sen!2s" 
        width="600" height="250" style="border:0;padding-bottom:150px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
<!-- End Location Section -->
</body>
<footer >
    <?php include_once("../parts/footer.html");
    ?>
</footer>
</html>
