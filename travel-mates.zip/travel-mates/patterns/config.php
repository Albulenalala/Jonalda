<?php
$conn=mysqli_connect("localhost","root","","travel");

if($conn)
{
    
}
else{
    echo "error";
}
?>