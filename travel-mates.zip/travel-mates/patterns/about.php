
<?php 
include_once("../parts/header.html");
?>

<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Mates</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="../assets/css/animate.css">
    <link rel="stylesheet" href="../assets/css/light_gallerr.min.css">
    <link rel="stylesheet" href="../assets/css/odometer.css">
    <link rel="stylesheet" href="../assets/css/select2.min.css">
    <link rel="stylesheet" href="../assets/css/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>


  <body>

    <!-- Start About Section -->
    <section class="cs_about cs_style_1">
      <div class="cs_height_140 cs_height_lg_80"></div>
      <div class="container">
        <div class="row align-items-center cs_gap_y_40 cs_mobile_reverse">
          <div class="col-lg-6">
            <div class="cs_section_heading cs_style_1">
              <h3 class="cs_section_title_up cs_ternary_font cs_accent_color cs_normal cs_fs_24">About Us</h3>
              <h2 class="cs_section_title cs_semibold cs_fs_56 mb-0">We are Professional Planners For your </h2>
            </div>
            <div class="cs_about_text">
              <p>We specialize in crafting tailored travel experiences that cater to your unique preferences and needs, ensuring seamless itineraries and unforgettable adventures. Let us handle the details while you focus on making memories!</p>
              <p class="mb-0 cs_accent_color cs_medium cs_fs_18">Speak to our Destination Experts at Direct Call +35568789856</p>
            </div>
            <ul class="cs_list cs_style_1 cs_mp0 cs_fs_18">
              <li>
                <i class="fa-solid fa-circle-check cs_accent_color"></i>
                All placges and activiates are carefully picked by us.
              </li>
              <li>
                <i class="fa-solid fa-circle-check cs_accent_color"></i>
                98% Course Completitation Rates
              </li>
              <li>
                <i class="fa-solid fa-circle-check cs_accent_color"></i>
                We are an award winning agency
              </li>
              <li>
                <i class="fa-solid fa-circle-check cs_accent_color"></i>
                Trusted by more than 80,000 customers
              </li>
            </ul>
            <a href="trips.php" class="cs_btn cs_style_1 cs_fs_18 cs_medium">
              Read More
              <svg width="20" height="10" viewBox="0 0 20 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M19.5866 5.69629H0.41235C0.184269 5.69629 0 5.46776 0 5.1849C0 4.90204 0.184269 4.67352 0.41235 4.67352H18.5906L16.0881 1.57004C15.927 1.37028 15.927 1.04587 16.0881 0.846109C16.2492 0.646349 16.5108 0.646349 16.6718 0.846109L19.8792 4.82374C19.9977 4.97076 20.0325 5.1897 19.9681 5.38147C19.9036 5.57164 19.7529 5.69629 19.5866 5.69629Z" fill="currentColor"/>
                <path d="M16.3435 9.11986C16.2384 9.11986 16.1333 9.08012 16.0538 8.99935C15.8935 8.83909 15.8935 8.57884 16.0538 8.41858L19.2487 5.22371C19.4089 5.06345 19.6692 5.06345 19.8294 5.22371C19.9897 5.38396 19.9897 5.64422 19.8294 5.80448L16.6346 8.99935C16.5538 9.08012 16.4487 9.11986 16.3435 9.11986Z" fill="currentColor"/>
              </svg>                
            </a>
          </div>
          <div class="col-lg-5 offset-lg-1"><img src="../assets/images/about_img.png" alt=""></div>
        </div>
      </div>
      <div class="cs_height_140 cs_height_lg_80"></div>
    </section>
    <!-- End About Section -->

        <!-- Start Why Choose Us Section -->
        <section>
      <div class="cs_height_135 cs_height_lg_75"></div>
      <div class="container">
        <div class="cs_section_heading cs_style_1 text-center">
          <h3 class="cs_section_title_up cs_ternary_font cs_accent_color cs_normal cs_fs_24">Why Choose Us</h3>
          <h2 class="cs_section_title cs_semibold cs_fs_56 mb-0 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Get The Best Travel Experience</h2>
        </div>
        <div class="cs_height_55 cs_height_lg_40"></div>
        <div class="cs_iconbox_4_wrap">
          <div>
            <div class="row cs_gap_y_45">
              <div class="col-lg-12 col-6">
                <div class="cs_iconbox cs_style_4">
                  <div class="cs_iconbox_icon cs_center">
                    <img src="../assets/images/icons/calendar_icon_2.svg" alt="Calendar Icon">
                  </div>
                  <h2 class="cs_iconbox_title cs_fs_24 cs_semibold">Set Travel Plan</h2>
                  <p class="cs_iconbox_subtitle mb-0">Distinctively impact client-centered ideas via future-proof paradigms.</p>
                </div>
              </div>
              <div class="col-lg-12 col-6">
                <div class="cs_iconbox cs_style_4">
                  <div class="cs_iconbox_icon cs_center">
                    <img src="../assets/images/icons/hotel-icon.svg" alt="Hotel Icon">
                  </div>
                  <h2 class="cs_iconbox_title cs_fs_24 cs_semibold">Luxary Hotel</h2>
                  <p class="cs_iconbox_subtitle mb-0">Distinctively impact client-centered ideas via future-proof paradigms.</p>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div class="cs_iconbox_4_thumb cs_center">
              <img src="../assets/images/about_4.png" alt="About Thumb">
            </div>
          </div>
          <div>
            <div class="row cs_gap_y_45">
              <div class="col-lg-12 col-6">
                <div class="cs_iconbox cs_style_4">
                  <div class="cs_iconbox_icon cs_center">
                    <img src="../assets/images/icons/compass_icon.svg" alt="Calendar Icon">
                  </div>
                  <h2 class="cs_iconbox_title cs_fs_24 cs_semibold">Explore Around</h2>
                  <p class="cs_iconbox_subtitle mb-0">Distinctively impact client-centered ideas via future-proof paradigms.</p>
                </div>
              </div>
              <div class="col-lg-12 col-6">
                <div class="cs_iconbox cs_style_4">
                  <div class="cs_iconbox_icon cs_center">
                    <img src="../assets/images/icons/headset_icon.svg" alt="Hotel Icon">
                  </div>
                  <h2 class="cs_iconbox_title cs_fs_24 cs_semibold">Support 24/7</h2>
                  <p class="cs_iconbox_subtitle mb-0">Distinctively impact client-centered ideas via future-proof paradigms.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="cs_height_135 cs_height_lg_75"></div>
    </section>
    <!-- End Why Choose Us Section -->
    <!-- Start Video Section -->
    <section>
  <div class="cs_height_140 cs_height_lg_80"></div>
  <div class="container">
    <div class="cs_video_block cs_style_1 cs_bg_filed position-relative" src="../assets/images/video_block.jpeg">
      <iframe width="100%" height="690" src="https://www.youtube.com/embed/QVoSgRbd69c?si=-0KKZprfroGXCYb6" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
      <a href="https://www.youtube.com/embed/QVoSgRbd69c?si=-0KKZprfroGXCYb6" class="cs_player_btn cs_center cs_accent_bg cs_video_open">
        <svg width="40" height="47" viewBox="0 0 40 47" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M36.9921 17.8114L9.63992 0.951019C7.66105 -0.267256 5.26855 -0.317908 3.23984 0.815524C1.21113 1.94878 0 4.01294 0 6.3367V39.9039C0 43.4175 2.83109 46.2914 6.31071 46.3104C6.32021 46.3104 6.32971 46.3105 6.33902 46.3105C7.42642 46.3104 8.55958 45.9696 9.61794 45.3238C10.4693 44.8043 10.7384 43.693 10.219 42.8417C9.69952 41.9902 8.58807 41.7212 7.73693 42.2407C7.2419 42.5426 6.75844 42.6988 6.33016 42.6987C5.01727 42.6916 3.61159 41.5669 3.61159 39.904V6.33679C3.61159 5.33994 4.13113 4.4547 5.00127 3.96853C5.87149 3.48236 6.89764 3.50407 7.74543 4.02606L35.0977 20.8864C35.9198 21.3926 36.3902 22.2366 36.3882 23.2021C36.3862 24.1674 35.9124 25.0095 35.0857 25.514L15.31 37.6224C14.4594 38.1432 14.192 39.2549 14.7128 40.1054C15.2335 40.956 16.3453 41.2234 17.1959 40.7026L36.9693 28.5956C38.8625 27.4407 39.9955 25.4272 40 23.2093C40.0045 20.9916 38.8797 18.9735 36.9921 17.8114Z" fill="currentColor" />
        </svg>
      </a>
      <h2 class="cs_video_title cs_fs_60 cs_semibold cs_white_color position-absolute mb-0">Our Journey <br> in Videos</h2>
      <span class="cs_location cs_fs_20 cs_white_color">
        <i class="fa-solid fa-location-dot"></i> Location Mountain Strait, Any State
      </span>
    </div>
  </div>
</section>


    <!-- End Video Section -->
  <!-- Start footer -->
  <?php include_once("../parts/footer.html");?>
    <!-- End footer -->

    <!-- Script -->
    <?php include_once("../partials/script.php")?>
  </body>

</html>
