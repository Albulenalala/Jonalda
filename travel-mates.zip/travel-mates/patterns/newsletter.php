<?php
session_start();
include_once("config.php");

$email = htmlspecialchars($_POST['email']);


$stmt = $conn->prepare("INSERT INTO `newsletter` ( email) VALUES (?)");
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("s",$email);

if ($stmt->execute()) {
    $_SESSION['message'] = "Thank you for subscribing!";
    header("Location: home.php"); 
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
 