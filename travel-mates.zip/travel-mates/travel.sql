-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2024 at 08:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travel`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `evaluation` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_id`, `category`, `username`, `destination`, `description`, `evaluation`) VALUES
(1, 'Curtural', 'Ana', 'Paris, France', 'Paris in the spring is magical. I strolled along the Seine, admiring the blooming cherry blossoms while enjoying a warm croissant. The Eiffel Tower shimmering at dusk became the perfect backdrop for new memories as I soaked in the vibrant atmosphere of this enchanting city.', 5),
(2, 'tourism', 'Ben', 'Bali, Indonesia ', 'Bali’s beaches are nothing short of paradise. I spent my days lounging on the soft sands of Seminyak and surfing the waves at Canggu. The vibrant local culture and delicious street food made every sunset unforgettable, wrapping up my trip with a sense of peace and contentment.', 5),
(3, 'Beach and Relaxation', 'Lea', 'Santorini, Greece', 'Famous for its stunning sunsets and whitewashed buildings, Santorini provides a breathtaking backdrop for a relaxing beach vacation combined with exquisite local cuisine.\r\n', 4),
(4, 'Nature and Adventure', 'Louis', 'Cape Town, South Africa', 'Surrounded by breathtaking landscapes, Cape Town boasts stunning beaches, Table Mountain, and diverse wildlife, attracting adventure lovers and nature enthusiasts alike.', 4),
(5, 'Urban Experience', 'Lucas', 'Barcelona, Spain', 'Barcelona has much to offer, from the stunning Sagrada Familia to the lively Las Ramblas. However, the overwhelming tourist volume can make certain areas feel congested, and finding authentic dining experiences amidst the tourist traps can be a challenge. It’s a beautiful city, but expect to navigate some drawbacks for the charm it provides.', 3);

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `book-id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone_nr` varchar(20) NOT NULL,
  `nr_persons` int(11) NOT NULL,
  `departure` varchar(100) NOT NULL,
  `departure_date` date NOT NULL,
  `return_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book-id`, `trip_id`, `name`, `email`, `phone_nr`, `nr_persons`, `departure`, `departure_date`, `return_date`) VALUES
(1, 1, 'maida', 'maidadaulle04@gmail.com', '3558965', 2, '0', '2024-10-18', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `contact-us`
--

CREATE TABLE `contact-us` (
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `comment` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact-us`
--

INSERT INTO `contact-us` (`name`, `email`, `subject`, `comment`) VALUES
('maida', 'maidadaulle04@gmail.com', 'travel', 'fedgfvkropgkeopgkierpgoke'),
('maida', 'maidadaulle04@gmail.com', 'travel', 'fedgfvkropgkeopgkierpgoke'),
('ana', 'swswfeddfe@ssss', 'eeee', 'eeeeeeeeeeeeeeeeeeeeeeeeeeeeee'),
('ssss', 'cdsfcswaf@ttt', 'esddd', 'bhtjhtjt'),
('madia', 'maidadaulle04@gmail.com', 'aaaaa', 'adssfcscf'),
('ssss', 'maidadaulle04@gmail.com', 'travel', 'sdfcsfcs'),
('ssss', 'maidadaulle04@gmail.com', 'esddd', 'dgdv ');

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE `destination` (
  `trip_id` int(11) NOT NULL,
  `continent` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `trip_type` varchar(20) NOT NULL,
  `departure_date` date NOT NULL,
  `nr_of_days` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `departure` varchar(60) NOT NULL,
  `destination` varchar(60) NOT NULL,
  `description` varchar(600) NOT NULL,
  `keywords` int(11) NOT NULL,
  `includes` varchar(300) NOT NULL,
  `excludes` varchar(250) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `quote` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `area` bigint(20) NOT NULL,
  `visa` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`trip_id`, `continent`, `country`, `city`, `trip_type`, `departure_date`, `nr_of_days`, `return_date`, `departure`, `destination`, `description`, `keywords`, `includes`, `excludes`, `price`, `image`, `quote`, `language`, `area`, `visa`) VALUES
(1, 'Europe', 'Italy', 'Rome', 'Culture & History', '2024-05-01', 7, '2024-05-08', 'New York', 'Rome', 'Rome, the Eternal City, is a captivating tapestry of history, art, and architecture that invites travelers to step back in time. Iconic landmarks such as the Colosseum and the Vatican City reveal the grandeur of ancient civilizations, while charming piazzas and cobbled streets exude a romantic ambiance. Indulge in authentic Italian cuisine at local trattorias, savoring every bite of pasta and gelato. With its rich heritage and vibrant atmosphere.', 0, ' guided tours, breakfast, accommodation', ' airfare, personal expenses', 850, 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Trevi_Fountain%2C_Rome%2C_Italy_2_-_May_2007.jpg/1920px-Trevi_Fountain%2C_Rome%2C_Italy_2_-_May_2007.jpg', 'Where every cobblestone tells a story!', 'English ,Italian', 1285, 'No'),
(2, 'Asia', 'Japan', 'Tokyo', 'Adventure', '2024-06-15', 10, '2024-06-25', ' Los Angeles', ' Tokyo', '  Tokyo is a mesmerizing blend of cutting-edge technology and rich tradition, offering visitors a unique cultural experience unlike any other. Vibrant neighborhoods showcase everything from neon-lit skyscrapers and bustling shopping districts to serene temples and tranquil gardens. This city is a culinary paradise, featuring diverse dining options, from traditional sushi to innovative street food. ', 0, ' entry fees, transportation, meals', 'international flights, travel insurance', 2200, 'https://wallpapers.com/images/featured-full/tokyo-night-pictures-cmpwgxnbei3ec7ns.jpg', ' Tradition meets innovation at every turn!', 'English, Japanese', 2194, 'Yes'),
(3, 'Europe', 'Spain', 'Barcelona', 'Culture', '2024-10-16', 4, '2024-10-21', 'London', 'Barcelona', 'Barcelona is a vibrant city where modernist architecture merges seamlessly with rich history and lively culture. Home to the masterpieces of Antoni Gaudí, including the iconic Sagrada Família and whimsical Park Güell, the city offers a feast for the eyes at every turn. ', 0, ' guided tours, breakfast, accommodation', ' airfare, personal expenses', 900, 'https://img2.10bestmedia.com/Images/Photos/378847/GettyImages-1085317916_55_660x440.jpg', 'The vibrant colors and rich flavors', 'English, Spanish', 101, 'No'),
(4, 'Europe', 'Iceland', 'Iceland', 'Adventure', '0000-00-00', 0, '0000-00-00', '', '', 'Iceland is a land of stunning contrasts, where dramatic landscapes of glaciers, volcanic craters, and geothermal hot springs create a playground for adventure seekers. Explore the breathtaking Golden Circle route, marvel at the stunning waterfalls of Gullfoss and Skógafoss, and soak in the famous Blue Lagoon. ', 0, ' guided tours, breakfast, accommodation', ' airfare, personal expenses', 1000, 'https://static.independent.co.uk/2023/05/04/10/iStock-1058181722.jpg?quality=75&width=1368&crop=3%3A2%2Csmart&auto=webp', 'Discover the land of fire and ice', 'Icelandic, English', 273, 'No'),
(5, '', 'South Africa', 'Cape Town', 'Culture', '0000-00-00', 0, '0000-00-00', '', '', 'Explore the stunning landscapes of Cape Town, highlighted by the iconic Table Mountain and picturesque beaches such as Camps Bay and Muizenberg. Hike scenic trails, visit the beautiful Cape of Good Hope, and dive into the local culture through vibrant markets and interactions with friendly residents. ', 0, ' guided tours, breakfast, accommodation', ' airfare, personal expenses,travel insurance', 2500, 'https://www.cruiseandtravel.co.uk/wp-content/uploads/2018/09/2CK09C2-1.jpg', 'Nature’s Masterpiece Awaits!', 'Xhosa , English', 2416, 'Yes'),
(6, '', 'Turkey', 'Istanbul', 'Culture', '0000-00-00', 0, '0000-00-00', '', '', 'Experience the rich history and vibrant culture of Istanbul, a city where East meets West. Explore iconic landmarks like the Hagia Sophia, Blue Mosque, and Topkapi Palace, which showcase its historical significance. Stroll through the lively Grand Bazaar, filled with spices, textiles, and unique crafts. ', 0, ' entry fees, transportation, meals', ' airfare, personal expenses', 500, 'https://www.civitatis.com/blog/wp-content/uploads/2024/03/shutterstock_291252509-1920x1248.jpg', 'A World of Wonders Awaits!', 'Turkish', 5343, 'No');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`email`) VALUES
('maidadaulle04@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `date_of_birth` date NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `position` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tour_book`
--

CREATE TABLE `tour_book` (
  `booking_id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number_of_children` int(11) NOT NULL,
  `number_of_adults` int(11) NOT NULL,
  `price_per_child` int(11) NOT NULL,
  `price_per_adult` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `language` varchar(50) NOT NULL,
  `tour_guide_id` int(11) NOT NULL,
  `notes` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_reports`
--

CREATE TABLE `user_reports` (
  `report_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `trip` varchar(100) NOT NULL,
  `trip_date` date NOT NULL,
  `description` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book-id`);

--
-- Indexes for table `destination`
--
ALTER TABLE `destination`
  ADD PRIMARY KEY (`trip_id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_book`
--
ALTER TABLE `tour_book`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `user_reports`
--
ALTER TABLE `user_reports`
  ADD PRIMARY KEY (`report_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `book-id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `destination`
--
ALTER TABLE `destination`
  MODIFY `trip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tour_book`
--
ALTER TABLE `tour_book`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_reports`
--
ALTER TABLE `user_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
