    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/jquery.slick.min.js"></script>
    <script src="assets/js/odometer.js"></script>
    <script src="assets/js/ripples.min.js"></script>
    <script src="assets/js/select2.min.js"></script>
    <script src="assets/js/light_gallery.min.js"></script>
    <script src="assets/js/main.js"></script>