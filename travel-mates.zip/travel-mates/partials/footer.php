<footer class="cs_footer cs_style_1 cs_white_color cs_bg_filed cs_primary_bg" data-src="assets/images/footer_bg.jpeg">
      <div class="cs_newsletter_1_wrap">
        <div class="container-fluid">
          <div class="cs_newsletter cs_style_1 cs_accent_bg">
            <div class="cs_newsletter_icon"><img src="assets/images/icons/envlop.png" alt="Icon"></div>
            <h2 class="cs_newsletter_title cs_fs_40 cs_bold mb-0 cs_white_color">Subscribe Our Newslatter</h2>
            <form action="#" class="cs_newsletter_form">
              <input type="text" class="cs_newsletter_form_field" placeholder="Enter your email address ...">
              <button type="submit" class="cs_btn cs_style_1 cs_fs_18 cs_medium">
                Subscribe<svg width="20" height="10" viewBox="0 0 20 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19.5866 5.69629H0.41235C0.184269 5.69629 0 5.46776 0 5.1849C0 4.90204 0.184269 4.67352 0.41235 4.67352H18.5906L16.0881 1.57004C15.927 1.37028 15.927 1.04587 16.0881 0.846109C16.2492 0.646349 16.5108 0.646349 16.6718 0.846109L19.8792 4.82374C19.9977 4.97076 20.0325 5.1897 19.9681 5.38147C19.9036 5.57164 19.7529 5.69629 19.5866 5.69629Z" fill="currentColor"></path>
                  <path d="M16.3435 9.11986C16.2384 9.11986 16.1333 9.08012 16.0538 8.99935C15.8935 8.83909 15.8935 8.57884 16.0538 8.41858L19.2487 5.22371C19.4089 5.06345 19.6692 5.06345 19.8294 5.22371C19.9897 5.38396 19.9897 5.64422 19.8294 5.80448L16.6346 8.99935C16.5538 9.08012 16.4487 9.11986 16.3435 9.11986Z" fill="currentColor"></path>
                </svg>                
              </button>
            </form>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="cs_footer_main">
          <div class="cs_footer_main_col">
            <div class="cs_footer_widget">
              <div class="cs_text_widget">
                <img src="assets/images/footer_logo.svg" alt="Logo">
              </div>
              <ul class="cs_contact_widget mb-0">
                <li>
                  <p>Call Us</p>
                  <p class="cs_fs_20">+423 5362 42365</p>
                </li>
                <li>
                  <p>Mail Us</p>
                  <p class="cs_fs_20">hello@travelpro.co</p>
                </li>
                <li>
                  <p>Follow Us</p>
                  <div class="cs_social_btn cs_style_1 d-flex">
                    <a href="https://www.linkedin.com/" target="_blank" class="cs_center"><i class="fa-brands fa-linkedin-in"></i>
                    </a>
                    <a href="https://twitter.com/" target="_blank" class="cs_center">
                      <i class="fa-brands fa-x-twitter"></i>
                    </a>
                    <a href="https://www.youtube.com/" target="_blank" class="cs_center"><i class="fa-brands fa-youtube"></i>
                    </a>                
                    <a href="https://slack.com/" target="_blank" class="cs_center">
                      <i class="fa-brands fa-slack"></i></a>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div class="cs_footer_main_col">
            <div class="cs_footer_widget">
              <h3 class="cs_footer_widget_title cs_fs_24 cs_semibold cs_white_color">Useful Links</h3>
              <ul class="cs_menu_widget">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">Activites</a></li>
                <li><a href="">Flights</a></li>
                <li><a href="">Organized Trips</a></li>
                <li><a href="">Hotels</a></li>
                <li><a href="">Booking</a></li>
                <li><a href="">Transfers</a></li>
                <li><a href="">Requests</a></li>
              </ul>
            </div>
          </div>
          <div class="cs_footer_main_col">
            <div class="cs_footer_widget">
              <h3 class="cs_footer_widget_title cs_fs_24 cs_semibold cs_white_color">Contact Info</h3>
              <ul class="cs_menu_widget">
                <li><a href="destination-details.php">Emirates, United Arabian</a></li>
                <li><a href="destination-details.php">Emirates, United Arabian</a></li>
                <li><a href="destination-details.php">New York City, USA</a></li>
                <li><a href="destination-details.php">New York City, USA</a></li>
                <li><a href="destination-details.php">One Bridge, Belguim</a></li>
                <li><a href="destination-details.php">One Bridge, Belguim</a></li>
                <li><a href="destination-details.php">Golden Frame, Dubai</a></li>
                <li><a href="destination-details.php">Golden Frame, Dubai</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="cs_footer_bottom">
          <div class="cs_copyright">Copyright © 2024 travelpro All rights reserved.</div>
          <ul class="cs_menu_widget_2 cs_mp0">
            <li><a href="#">Terms of Services</a></li>
          </ul>
        </div>
      </div>
    </footer>