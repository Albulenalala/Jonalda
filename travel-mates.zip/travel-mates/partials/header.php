<header class="cs_site_header cs_style_1 cs_fs_18 cs_sticky_header">
      <div class="cs_main_header">
        <div class="cs_main_header_in">
          <div class="cs_main_header_left">
            <a class="cs_site_branding" href="index.php">
              <img src="assets/images/logo.svg" alt="Logo">
            </a>
          </div>
          <div class="cs_main_header_center">
            <div class="cs_nav cs_medium cs_primary_font">
              <ul class="cs_nav_list">
                <li class="menu-item-has-children">
                  <a href="index.php">Home</a>
                  <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="index-v2.php">Home v2</a></li>
                    <li><a href="index-v3.php">Home v3</a></li>
                  </ul>
                </li>
                <li><a href="about.php">About Us</a></li>
                <li class="menu-item-has-children">
                  <a href="destination.php">Destinations</a>
                  <ul>
                    <li><a href="destination.php">Destination</a></li>
                    <li><a href="destination-details.php">Destination Details</a></li>
                  </ul>
                </li>
                <li class="menu-item-has-children">
                  <a href="tour.php">Tours</a>
                  <ul>
                    <li><a href="tour.php">Tour</a></li>
                    <li><a href="tour-details.php">Tour Details</a></li>
                  </ul>
                </li>
                <li class="menu-item-has-children">
                  <a href="blog.php">Blog</a>
                  <ul>
                    <li><a href="blog.php">Blog</a></li>
                    <li><a href="blog-details.php">Blog Details</a></li>
                  </ul>
                </li>
                <li><a href="contact.php">Contacts</a></li>
              </ul>
            </div>
          </div>
          <div class="cs_main_header_right">
            <div class="cs_header_toolbox">
              <div>
                <button class="cs_search_btn cs_fs_24" type="button"><i class="fa-solid fa-magnifying-glass"></i></button>
              </div>
              <div class="cs_fs_20 cs_medium">+8 (123) 985 789</div>
            </div>
          </div>
        </div>
      </div>
    </header>